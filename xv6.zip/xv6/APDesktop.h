#ifndef APDESKTOP_H
#define APDESKTOP_H

typedef struct Item
{
	int wndId;
	char title[MAX_ITEM_TITLE]


};


typedef struct ItemData
{
	


};



#endif